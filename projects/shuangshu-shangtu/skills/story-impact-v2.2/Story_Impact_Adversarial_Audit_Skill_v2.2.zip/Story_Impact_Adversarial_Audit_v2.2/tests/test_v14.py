import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from editorial_leakage_gate import scan
from v14_regression import check

class NewRedteamTests(unittest.TestCase):
 def test_editorial_leak(self):
  self.assertEqual(len(scan('# E001《x》\n△ 没有重复付钱或重复上面。')),1)
  self.assertEqual(len(scan('# E001《x》\n△ 不让演员口念52项清单。')),1)
  self.assertEqual(len(scan('# E001《x》\n△ 她的成长不是在镜前宣布。')),1)
 def test_legitimate_action(self):
  self.assertEqual(len(scan('# E001《x》\n△ 她把钱交到真正做工的人手里。')),0)
 def test_frozen(self):
  a='\n'.join(f'# E{i:03}《t》\n### 【00:00–02:30】\n【E{i:03}完】' for i in range(1,65))
  b=a.replace('# E001《t》','# E001《edited》')
  self.assertIn('FROZEN_CHANGED:E001',check(a,b)['issues'])
 def test_market_unverified(self):
  a='\n'.join(f'# E{i:03}《t》\n### 【00:00–02:30】\n【E{i:03}完】' for i in range(1,65))
  self.assertEqual(check(a,a)['market_grade'],'UNVERIFIED')
if __name__=='__main__':unittest.main()
