import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from v16_audit import audit

def sample():
    return ''.join(f'# E{i:03d}《测试》\n### 【场景｜00:00–02:30】\n△ 对话\n【'+('全剧终' if i==64 else f'E{i:03d}完')+'】\n' for i in range(1,65))

class V16Tests(unittest.TestCase):
    def test_counts(self):
        r=audit(sample());self.assertEqual(r['episodes'],64);self.assertEqual(r['scenes'],64)
    def test_never_market_certifies(self):
        self.assertFalse(audit(sample())['can_certify_market_sss'])
    def test_never_runtime_certifies(self):
        self.assertFalse(audit(sample())['can_certify_runtime'])
    def test_frozen_guard(self):
        a=sample();b=a.replace('E002《测试》','E002《被改》');r=audit(b,a,'双姝商途');self.assertIn('FROZEN_CHANGED',[x['code'] for x in r['flags']])
    def test_retired_phone(self):
        r=audit(sample()+'手机扫码',project='双姝商途');self.assertIn('RETIRED_PLOT_REINTRODUCED',[x['code'] for x in r['flags']])
    def test_generic_not_project_scoped(self):
        r=audit(sample());self.assertNotIn('CANON_NUMBER_OR_STATE_MISSING',[x['code'] for x in r['flags']])
