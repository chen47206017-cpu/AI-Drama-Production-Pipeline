import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'scripts'))
from public_authority_gate import audit_case
class TestPublicDuty(unittest.TestCase):
 def test_private_agreement(self):self.assertEqual(audit_case({'official_decides_private_contract':True})['status'],'FLAGGED')
 def test_romantic_favor(self):self.assertEqual(audit_case({'selective_exemption_for_love':True})['status'],'FLAGGED')
 def test_unauthorized_rope(self):self.assertEqual(audit_case({'guard_line_held_by_merchant':True})['status'],'FLAGGED')
 def test_handoff_missing(self):self.assertEqual(audit_case({'official_leaves_live_blockade':True})['status'],'FLAGGED')
 def test_handoff_complete(self):self.assertEqual(audit_case({'official_leaves_live_blockade':True,'handoff_staff':'徐','handoff_route':'河巷','handoff_confirmed':True})['status'],'STRUCTURED_GATE_PASS')
 def test_reopen_unverified(self):self.assertEqual(audit_case({'route_reopened':True,'guard_present':True})['status'],'FLAGGED')
 def test_arrival_not_same_as_agreement(self):self.assertEqual(audit_case({'route_reopened':True,'guard_present':True,'physical_route_verified':True,'staff_confirmed_on_paper':True,'staff_arrived':False})['status'],'FLAGGED')
 def test_owner_transfer(self):self.assertEqual(audit_case({'goods_moved_by_official':True,'owner_agreed':True})['status'],'STRUCTURED_GATE_PASS')
 def test_owner_no_consent(self):self.assertEqual(audit_case({'goods_moved_by_official':True})['status'],'FLAGGED')
 def test_public_hazard(self):self.assertEqual(audit_case({'safety_stop':True,'independent_hazard':'堵路'})['status'],'STRUCTURED_GATE_PASS')
 def test_safety_without_hazard(self):self.assertEqual(audit_case({'safety_stop':True})['status'],'FLAGGED')
 def test_unlawful_corruption_as_story_not_automatically_approved(self):self.assertEqual(audit_case({'selective_exemption_for_love':True,'fictional_corruption_plot':True})['status'],'FLAGGED')
