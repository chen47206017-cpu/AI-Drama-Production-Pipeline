import unittest,sys,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from v20_custody_gate import check
class TestV20Custody(unittest.TestCase):
 def test_machine_cannot_release(self):
  self.assertEqual(check('')['status'],'review_not_release')
 def test_resurrection_warns(self):
  a=('# E001《x》\n'+('销毁')+('没有丢掉'))
  self.assertTrue(any('disposal_resurrection' in x for x in check(a)['warnings']))
 def test_reinspect_warns(self):
  self.assertTrue(any('repeated_inspection' in x for x in check('# E001《x》\n已验收 尚未拆验')['warnings']))
 def test_proper_sequences_no_fake_pass(self):
  self.assertFalse(any('repeated_inspection' in x for x in check('# E001《x》\n代领待验；本人亲验，随后搬走')['warnings']))
if __name__=='__main__': unittest.main()
