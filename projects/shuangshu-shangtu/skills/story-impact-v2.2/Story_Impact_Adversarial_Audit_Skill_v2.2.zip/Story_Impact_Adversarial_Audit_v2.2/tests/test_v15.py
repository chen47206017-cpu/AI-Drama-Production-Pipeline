import unittest, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from v15_evidence_gate import assess

def fake_episode(n,txt=''):
 return f'# E{n:03}《测试》\n### 【室内｜00:00–02:30】\n△ {txt}\n【'+('全剧终' if n==64 else f'E{n:03}完')+'】\n'
class TestsV15(unittest.TestCase):
 def test_market_grade_unverified(self):
  self.assertIn('UNVERIFIED',Path(__file__).resolve().parents[1].joinpath('SKILL.md').read_text())
 def test_frozen_guard_is_present(self):
  self.assertIn('FROZEN_CHANGED',Path(__file__).resolve().parents[1].joinpath('scripts/v13_regression.py').read_text())
 def test_count_contract_is_present(self):
  self.assertIn('52项',Path(__file__).resolve().parents[1].joinpath('scripts/v15_evidence_gate.py').read_text())
 def test_source_provenance_flag(self):
  self.assertIn('SOURCE_PENDING',Path(__file__).resolve().parents[1].joinpath('SKILL.md').read_text())
 def test_rights_canon_separation(self):
  self.assertIn('新剧加载自己的禁用表',Path(__file__).resolve().parents[1].joinpath('SKILL.md').read_text())
 def test_market_format_separation(self):
  self.assertIn('同平台、真人、同60日',Path(__file__).resolve().parents[1].joinpath('SKILL.md').read_text())
