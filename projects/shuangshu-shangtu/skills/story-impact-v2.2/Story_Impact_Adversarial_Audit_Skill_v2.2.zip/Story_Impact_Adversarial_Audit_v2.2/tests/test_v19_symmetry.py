import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from v19_symmetry_and_fulfillment import case_check
class RedteamV19(unittest.TestCase):
    def check(self,kind,**kw):return case_check({'id':'case','kind':kind,**kw})
    def test_public_romantic_favor_rejected(self):
        self.assertIn('OFFICE_PRIVATE_FAVOR',self.check('official',special_access_for_romance=True)['hard_failures'])
    def test_equal_treatment(self):
        self.assertEqual([],self.check('official',public_blockade=True,observable_public_hazard=True,comparable_rival=True,different_treatment_without_public_reason=False)['hard_failures'])
    def test_selective_exception_rejected(self):
        self.assertIn('UNEQUAL_COMPETITOR_RULE',self.check('official',comparable_rival=True,different_treatment_without_public_reason=True)['hard_failures'])
    def test_no_merchant_guard(self):
        self.assertIn('MERCHANT_AS_PUBLIC_GUARD',self.check('official',merchant_holds_public_guard_line=True)['hard_failures'])
    def test_shift_handoff_requirements(self):
        self.assertIn('SHIFT_WITHOUT_PROVEN_HANDOFF',self.check('official',official_leaves_guard=True,guard_receiver=True,route_repeated=False,seal_still_active=True)['hard_failures'])
    def test_route_guard_staff_not_approval(self):
        self.assertIn('NO_REOPEN_BEFORE_SITE_CHECK',self.check('official',reopen_route=True,guard_arrived=True,on_site_route_approved=False)['hard_failures'])
    def test_double_free_sample(self):
        self.assertIn('DOUBLE_SERVICE_OR_UNPAID_SAMPLE',self.check('commercial',completed_service_in_pricing_scene=True,same_service_fulfilled_later=True)['hard_failures'])
    def test_quote_is_not_deposit(self):
        self.assertEqual([],self.check('commercial',sale_claimed=False,cash_as_revenue_before_delivery=False)['hard_failures'])
    def test_revenue_before_delivery_rejected(self):
        self.assertIn('ADVANCE_AS_EARNED_REVENUE',self.check('commercial',cash_as_revenue_before_delivery=True)['hard_failures'])
    def test_competitive_proof(self):
        self.assertEqual([],self.check('commercial',sale_claimed=True,customer_chose=True,owner_delivered=True,money_state_known=True)['hard_failures'])
    def test_invalid_rival_motive(self):
        self.assertIn('RIVAL_SERVES_HERO_NO_MOTIVE',self.check('commercial',rival_staff_demonstrates_at_hero_shop=True,independent_rival_motive=False)['hard_failures'])
    def test_injury_identity_warn_only(self):
        self.assertIn('INJURED_PARTY_ID_COLLISION',self.check('event_id',two_separate_incidents=True,separate_injured_person_ids=False)['human_review'])
if __name__=='__main__':unittest.main()
