import sys, pathlib, unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'scripts'))
from v22_story_payoff_gate import *
class V22Tests(unittest.TestCase):
 def test_unverified_exact_quote(self): self.assertEqual(evidence_admissibility({'claims_exact_quote':True}),'HOLD_SOURCE_PROOF')
 def test_grounded_exact_quote(self): self.assertEqual(evidence_admissibility({'claims_exact_quote':True,'exact_quote_verified':True}),'ELIGIBLE_FOR_EDITOR_REVIEW')
 def test_canon_conflict(self): self.assertEqual(evidence_admissibility({'canon_conflict':True,'exact_quote_verified':True}),'REJECT_CONFLICT')
 def test_official_favor(self): self.assertEqual(evidence_admissibility({'unauthorized_official_favor':True}),'REJECT_CONFLICT')
 def test_unoriginated_prop(self): self.assertEqual(evidence_admissibility({'new_prop_or_money':True}),'HOLD_PROVENANCE')
 def test_originated_prop(self): self.assertEqual(evidence_admissibility({'new_prop_or_money':True,'origin_accounted':True}),'ELIGIBLE_FOR_EDITOR_REVIEW')
 def test_timing_required(self): self.assertEqual(evidence_admissibility({'needs_actor_timing':True}),'HOLD_STAGE_TEST')
 def test_payoff_chain(self): self.assertTrue(payoff_chain(dict(choice=1,foregone_alternative=1,observed_consequence=1,downstream_effect=1))['valid'])
 def test_payoff_missing(self): self.assertEqual(payoff_chain(dict(choice='x'))['missing'],['foregone_alternative','observed_consequence','downstream_effect'])
 def test_duplicate_payment(self): self.assertEqual(fulfill_once([dict(entity='a',transaction_id='1',state='deposit_paid'),dict(entity='a',transaction_id='1',state='deposit_paid')]),[(1,'repeated_cash_event')])
 def test_distinct_payments(self): self.assertEqual(fulfill_once([dict(entity='a',transaction_id='1',state='deposit_paid'),dict(entity='a',transaction_id='1',state='balance_paid')]),[])
 def test_money_sum(self): self.assertTrue(correct_sum([31*22,12*25,9*34],1288))
 def test_market_unreleased(self): self.assertFalse(market_tier_eligible(dict(released=False)))
 def test_no_cross_form(self): self.assertFalse(market_tier_eligible(dict(released=True,metric='daily_heat',format='live_action')))
 def test_frozen_episodes(self):
  src='# E001《甲》\nabc\n# E002《乙》\nxyz\n';self.assertTrue(exact_scene_frozen(src,src,episode_numbers=(1,2)))
 def test_changed_frozen_episode(self):
  src='# E001《甲》\nabc\n# E002《乙》\nxyz\n';self.assertFalse(exact_scene_frozen(src,src.replace('abc','abX'),episode_numbers=(1,2)))
if __name__=='__main__':unittest.main()
