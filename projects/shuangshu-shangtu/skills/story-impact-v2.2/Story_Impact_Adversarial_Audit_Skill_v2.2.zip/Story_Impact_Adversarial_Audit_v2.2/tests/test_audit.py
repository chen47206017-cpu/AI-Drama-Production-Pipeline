import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from audit_script import parse

class TestAudit(unittest.TestCase):
    def test_extract_episodes(self):
        sample='# E001《甲》\n### 【门口｜00:00–00:15】\n甲：“来。”\n### 【街上｜00:15–02:30】\n△ 回家。\n【E001完】\n# E002《乙》\n### 【屋里｜00:00–02:30】\n△ 点头。\n【E002完】'
        rows,flags,s=parse(sample)
        self.assertEqual(len(rows),2)
        self.assertEqual(rows[0]['scene_count'],2)
        self.assertEqual(s['episodes_timed_to_150s'],2)
    def test_gap_issues_not_pass(self):
        s='# E001《甲》\n### 【a｜00:00–00:10】\n△ 茶。\n### 【b｜00:20–02:30】\n△ 完。\n【E001完】'
        rows,flags,stats=parse(s)
        self.assertIn('TIME_GAP_OR_OVERLAP',[x['code'] for x in flags])
        self.assertFalse(stats['can_certify_actual_runtime'])

if __name__ == '__main__': unittest.main()
