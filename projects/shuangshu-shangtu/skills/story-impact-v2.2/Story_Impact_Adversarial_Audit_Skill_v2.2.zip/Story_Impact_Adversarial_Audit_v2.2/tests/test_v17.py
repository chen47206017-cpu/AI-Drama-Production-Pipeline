import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from v17_gate import analyze

def fake():return ''.join(f'# E{i:03d}《场》\n### 【一间房｜00:00–02:30】\n△ 画面\n【'+('全剧终' if i==64 else f'E{i:03d}完')+'】\n' for i in range(1,65))
class V17Test(unittest.TestCase):
 def test_source_lock(self):
  a=fake();self.assertEqual(analyze(a,a)['changed_episode_count'],0)
 def test_chapter_change(self):
  a=fake();b=a.replace('E025《场》','E025《柜口抉择》');self.assertEqual(analyze(b,a)['changed_episodes'],['E025'])
 def test_frozen_violation(self):
  a=fake();b=a.replace('E003《场》','E003《变》');res=analyze(b,a,project='双姝商途');self.assertTrue(any(x['code']=='FROZEN_CHANGED' for x in res['hard_failures']))
 def test_market_not_automatically_certified(self):self.assertFalse(analyze(fake())['can_certify_market_sss'])
 def test_runtime_not_automatically_certified(self):self.assertTrue(analyze(fake())['proof_requires_actor_timing'])
 def test_editorial_leak(self):
  r=analyze(fake().replace('△ 画面','△ 不是49秒内完成动作',1));self.assertEqual(len(r['editorial_leak_review']),1)
 def test_project_scope(self):
  r=analyze(fake()+'手机扫码',project='generic');self.assertFalse(r['retired_assets'])
 def test_user_project_assets(self):
  r=analyze(fake()+'手机扫码',project='双姝商途');self.assertTrue(r['retired_assets'])
