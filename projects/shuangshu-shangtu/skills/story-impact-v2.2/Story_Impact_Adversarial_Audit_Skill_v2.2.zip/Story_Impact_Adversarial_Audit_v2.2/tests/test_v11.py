import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from calibrate_rank import classify
from release_guard import run
class TestNewGuards(unittest.TestCase):
    def test_23_7_bill(self):self.assertEqual(classify('douyin','ai_drama','monthly_increment_views','2026-09',2370000000)['grade'],'SSS')
    def test_heat_must_not_be_views(self):self.assertEqual(classify('hongguo','real','avg_daily_heat','2026-09',59786000)['grade'],'UNVERIFIED')
    def test_unreleased(self):self.assertEqual(classify('douyin','ai_drama','monthly_increment_views','2026-09',5000000000,False)['grade'],'UNVERIFIED')
    def test_frozen(self):
        s='# E001《x》\n### 【a】\n【E001完】\n# E002《y》\n### 【b】\n【全剧终】'
        self.assertEqual(run(s,2,2,s,['E001'])['status'],'STATIC_PASS_ONLY')
        self.assertIn('FROZEN_DRIFT:E001',run(s.replace('【E001完】','不同'),2,2,s,['E001'])['failed'])
if __name__=='__main__':unittest.main()
