import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'scripts'))
from v13_regression import check

def make():
    lines = []
    for i in range(1,65):
        lines.append(f'# E{i:03d}《测试》\n')
        if i==32:lines.append('31笔×22；52笔；120＋1288－468＝940；300文押钱；180文首月租；余460文\n')
        if i==53:lines.append('【跨日卡：过了两日】\n')
        if i==64:lines.append('问得到就问\n')
        n=5 if i<=12 else 4
        lines.append('### 【片段｜00:00–02:30】\n' * n)
        lines.append('【全剧终】\n' if i==64 else f'【E{i:03d}完】\n')
    return ''.join(lines)

class V13(unittest.TestCase):
    def test_equal_has_no_change(self):
        x=make(); r=check(x,x)
        self.assertEqual(r['changed_count'],0)
        self.assertEqual(r['issues'],[])
    def test_frozen_changed(self):
        x=make(); y=x.replace('《测试》','《改了》',1)
        self.assertTrue(any('FROZEN_CHANGED' in z for z in check(x,y)['issues']))
    def test_bad_52(self):
        x=make(); y=x.replace('52笔','54笔')
        self.assertIn('E032_BAD_COUNT_54',check(x,y)['issues'])
    def test_runtime_unverified(self):
        self.assertFalse(check(make(),make())['runtime_certified'])
    def test_market_unverified(self):
        self.assertEqual(check(make(),make())['market_grade'],'UNVERIFIED')
