import unittest,sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent.parent/'scripts'))
from v21_source_and_pacing_gate import *
TXT='# E001《门》\n### 【甲｜00:00–01:00】\n甲说“别碰”。\n### 【乙｜01:00–02:30】\n△收尾\n【E001完】'
class V21Evidence(unittest.TestCase):
    def test_exact_quote_pass(self):
        self.assertEqual(quote_anchor_check(TXT,[dict(episode=1,quote='别碰',claimed_exact=True)])[0]['evidence_status'],'EXACT_ANCHOR_FOUND')
    def test_madeup_dialogue_rejected(self):
        self.assertEqual(quote_anchor_check(TXT,[dict(episode=1,quote='债主砸店',claimed_exact=True)])[0]['evidence_status'],'UNSUPPORTED_QUOTE')
    def test_paraphrase_needs_human(self):
        self.assertEqual(quote_anchor_check(TXT,[dict(episode=1,quote='不要用手碰',claimed_exact=False)])[0]['evidence_status'],'PARAPHRASE_NEEDS_HUMAN_READ')
    def test_unknown_ep_is_not_pass(self):
        self.assertEqual(quote_anchor_check(TXT,[dict(episode=2,quote='别碰',claimed_exact=True)])[0]['evidence_status'],'UNKNOWN_EPISODE')
    def test_cohort_identical(self):
        d=dict(platform='Douyin',format='live-action',metric='monthly_play_increment',unit='plays',window_days=30)
        self.assertTrue(platform_metric_cohort(d,d))
    def test_heat_vs_plays_not_comparable(self):
        a=dict(platform='Hongguo',format='live-action',metric='daily_heat',unit='index',window_days=30)
        b=dict(platform='Douyin',format='live-action',metric='monthly_play_increment',unit='plays',window_days=30)
        self.assertFalse(platform_metric_cohort(a,b))
    def test_window_mismatch_not_comparable(self):
        a=dict(platform='Douyin',format='live-action',metric='plays',unit='plays',window_days=30)
        self.assertFalse(platform_metric_cohort(a,{**a,'window_days':60}))
    def test_unreleased_cannot_claim_market_sss(self):
        self.assertFalse(prohibit_prelaunch_market_tier(False,True))
    def test_release_requires_verified_data(self):
        self.assertFalse(prohibit_prelaunch_market_tier(True,False))
    def test_timing_continuity_pass(self):
        self.assertEqual(episode_pacing_flags(TXT)['warnings'],[])
    def test_timing_gap_is_flag(self):
        bad=TXT.replace('01:00–02:30','01:05–02:30')
        self.assertIn('E001:scene_gap_or_overlap_1',episode_pacing_flags(bad)['warnings'])
    def test_perf_never_certified(self):
        self.assertIs(episode_pacing_flags(TXT)['certifies_performance'],False)
    def test_project_bans_configured_only(self):
        self.assertEqual(project_exclusions('手机没带来',['手机','假门票']),{'手机':1})
if __name__=='__main__':unittest.main()
