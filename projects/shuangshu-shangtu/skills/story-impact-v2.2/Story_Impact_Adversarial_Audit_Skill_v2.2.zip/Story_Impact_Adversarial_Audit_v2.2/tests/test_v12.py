import unittest,sys
from pathlib import Path
base=Path(__file__).resolve().parents[1];sys.path.insert(0,str(base/'scripts'))
from market_cohort import classify
from transaction_guard import audit
class MarketTests(unittest.TestCase):
 def test_unreleased(self):self.assertEqual(classify([],{'released':False})['grade'],'UNVERIFIED')
 def test_insufficient(self):self.assertEqual(classify([],{'released':True})['grade'],'INSUFFICIENT_SAMPLE')
 def test_mixed_formats(self):
  rs=[dict(platform='douyin',format='real',metric='monthly_increment_views',period_start='2026-09-01',period_end='2026-09-30',aggregation='series',source_date='2026-10-12',views=i) for i in range(30)];rs[4]['format']='ai'
  self.assertEqual(classify(rs,{**rs[0],'released':True})['grade'],'MIXED_COHORT')
 def test_high_percentile(self):
  rs=[dict(platform='douyin',format='real',metric='monthly_increment_views',period_start='2026-09-01',period_end='2026-09-30',aggregation='series',source_date='2026-10-12',views=i) for i in range(100)]
  self.assertEqual(classify(rs,{**rs[0],'views':1000,'released':True})['grade'],'SSS')
class TxTests(unittest.TestCase):
 def test_good(self): self.assertEqual(audit([{'id':'x','owner':'a','total_price':130,'events':[{'state':'deposit_received','amount':30},{'state':'performed','amount':0},{'state':'final_paid','amount':100}]}]),[])
 def test_double_deposit(self): self.assertTrue(any(x[1]=='overcollected' for x in audit([{'id':'x','owner':'a','total_price':130,'events':[{'state':'deposit_received','amount':30},{'state':'deposit_received','amount':30},{'state':'performed','amount':0},{'state':'final_paid','amount':100}]}])))
 def test_final_before_service(self):self.assertTrue(audit([{'id':'x','owner':'a','total_price':50,'events':[{'state':'final_paid','amount':50}]}]))
if __name__=='__main__':unittest.main()
