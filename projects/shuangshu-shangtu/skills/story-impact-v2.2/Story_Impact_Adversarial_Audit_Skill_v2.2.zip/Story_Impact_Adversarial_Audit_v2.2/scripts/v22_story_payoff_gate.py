"""v2.2 editorial trust and payoff contracts. Structured input required; advisory, not automated taste judge."""
import re

def evidence_admissibility(case):
    """Reject report-driven changes that invent canon, treat unverified exact quotes as source, or confer unearned public favors."""
    if case.get('canon_conflict') or case.get('unauthorized_official_favor'):
        return 'REJECT_CONFLICT'
    if case.get('claims_exact_quote') and not case.get('exact_quote_verified'):
        return 'HOLD_SOURCE_PROOF'
    if case.get('new_prop_or_money') and not case.get('origin_accounted'):
        return 'HOLD_PROVENANCE'
    if case.get('needs_actor_timing') and not case.get('performed_timing_verified'):
        return 'HOLD_STAGE_TEST'
    return 'ELIGIBLE_FOR_EDITOR_REVIEW'

def payoff_chain(state):
    """All four fields must be grounded in a script, or mark it for review. This is not a prediction of viewer affect."""
    required=('choice','foregone_alternative','observed_consequence','downstream_effect')
    return {'valid':all(bool(state.get(k)) for k in required),'missing':[k for k in required if not state.get(k)]}

def fulfill_once(events):
    """Event objects: entity, transaction_id, state, amount(optional). State transitions must not duplicate cash transactions."""
    seen=set(); errors=[]
    legitimate=('inquired','sampled','reserved','deposit_paid','performed','accepted','balance_paid','refunded','cancelled')
    for i,x in enumerate(events):
        status=x.get('state'); tx=x.get('transaction_id'); actor=x.get('entity')
        if status not in legitimate: errors.append((i,'unknown_state'))
        if status in ('deposit_paid','balance_paid','refunded'):
            key=(tx,actor,status)
            if key in seen:errors.append((i,'repeated_cash_event'))
            seen.add(key)
    return errors

def exact_scene_frozen(before,after,episode_numbers=(1,2,3,4,5)):
    r=re.compile(r'(?ms)^# E(\d{3})《[^\n]+》\n.*?(?=^# E\d{3}《|\Z)')
    def ep(s):
        return {int(n):v for n,v in ((re.search(r'^# E(\d{3})',m.group()).group(1),m.group()) for m in r.finditer(s))}
    a=ep(before);b=ep(after)
    return len(a)==len(b) and all(a.get(n)==b.get(n) for n in episode_numbers)

def correct_sum(parts,stated):
    if not isinstance(stated,(int,float)):return False
    return sum(parts)==stated

def market_tier_eligible(record):
    required=('released','platform','format','metric','window_days','as_of','source','verified_plays')
    return all(record.get(k) for k in required) and record['metric'] in ('monthly_play_increment','cumulative_plays') and record['format'] in ('live_action','ai','animation')
