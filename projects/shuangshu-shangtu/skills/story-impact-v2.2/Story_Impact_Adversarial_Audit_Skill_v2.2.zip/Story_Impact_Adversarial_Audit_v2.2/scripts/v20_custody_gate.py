#!/usr/bin/env python3
"""Conservative static checks: flags only, not universal factual proof."""
import re,sys,json,pathlib
def check(text):
    eps=dict((int(n),b) for n,b in re.findall(r"^# E(\d{3})《[^\n]+》\n(.*?)(?=^# E\d{3}《|\Z)",text,re.M|re.S))
    flags=[]
    if len(eps)!=64: flags.append("episode_count_check_requires_project_config")
    for n,b in eps.items():
        if "销毁" in b and "没有丢掉" in b: flags.append(f"E{n:03d}:check_suspected_disposal_resurrection")
        if "已验收" in b and "尚未拆验" in b: flags.append(f"E{n:03d}:check_repeated_inspection")
    return {"episodes_found":len(eps),"warnings":flags,"status":"review_not_release"}
if __name__=='__main__':
    text=pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
    print(json.dumps(check(text),ensure_ascii=False,indent=2))
