#!/usr/bin/env python3
"""V1.6 script audit: FLAGs for human review, never certifies runtime or SSS."""
import re, json, argparse, hashlib
from pathlib import Path
RE=re.compile(r'(?m)^# E(\d{3})《')
SCENE=re.compile(r'(?m)^### 【')
TIME=re.compile(r'(\d{2}):(\d{2})[–—-](\d{2}):(\d{2})')

def episodes(source):
    ms=list(RE.finditer(source));out={}
    for i,m in enumerate(ms):out[int(m[1])]=source[m.start():ms[i+1].start() if i+1<len(ms) else len(source)]
    return out

def audit(text, baseline=None, project='generic'):
    ep=episodes(text);issues=[]
    if len(ep)!=64 or sorted(ep)!=list(range(1,65)):issues.append({'code':'EPISODES_NOT_64','level':'P0'})
    if project=='双姝商途':
        if text.count('### 【')!=268:issues.append({'code':'SCENE_COUNT_CHANGED','level':'P0'})
        if not all(re.search(fr'【E{i:03d}完】',ep.get(i,'')) for i in range(1,64)):issues.append({'code':'END_MARK_MISSING','level':'P0'})
        if '【全剧终】' not in ep.get(64,''):issues.append({'code':'FINALE_MARK_MISSING','level':'P0'})
        for phrase in ['妆务31','引路12','场务9','52项','1288','468','940','来处待核']:
            if phrase not in text:issues.append({'code':'CANON_NUMBER_OR_STATE_MISSING','level':'P0','detail':phrase})
        if baseline:
            old=episodes(baseline)
            if any(ep.get(i)!=old.get(i) for i in range(1,6)):issues.append({'code':'FROZEN_CHANGED','level':'P0'})
    for i,body in ep.items():
        sm=list(SCENE.finditer(body))
        for j,m in enumerate(sm):
            block=body[m.start():sm[j+1].start() if j+1<len(sm) else len(body)]
            mt=TIME.search(m.group(0)+block[:90])
            if mt:
                a,b,c,d=map(int,mt.groups());dur=(c*60+d)-(a*60+b)
                # length is only a proxy; no automatic pass/fail based on it.
                count=len(re.findall('[\u4e00-\u9fff]',block))
                if dur>0 and count/dur>8.5:
                    issues.append({'code':'SCENE_DENSITY_REVIEW','level':'REVIEW','episode':f'E{i:03d}','seconds':dur,'hanzi':count})
    bad=[x for x in ['手机扫码','现代笔记本穿越','审计师制服'] if x in text]
    if project=='双姝商途':
        issues +=[{'code':'RETIRED_PLOT_REINTRODUCED','level':'P0','detail':x} for x in bad]
    return {'episodes':len(ep),'scenes':len(SCENE.findall(text)),'flags':issues,'can_certify_runtime':False,'can_certify_market_sss':False,'release':'HOLD'}

def main():
    p=argparse.ArgumentParser();p.add_argument('script',type=Path);p.add_argument('--baseline',type=Path);p.add_argument('--project',default='generic');p.add_argument('--out',type=Path)
    a=p.parse_args();res=audit(a.script.read_text(),a.baseline.read_text() if a.baseline else None,a.project)
    t=json.dumps(res,ensure_ascii=False,indent=2)
    if a.out:a.out.write_text(t)
    print(t)
if __name__=='__main__':main()
