#!/usr/bin/env python3
"""v1.5 evidence gate; only structural facts, never certifies audience retention."""
import re, json, argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent))
import v14_regression

def assess(base,cand,ledger):
    result=v14_regression.check(base,cand)
    issues=list(result['issues']); ep=re.findall(r'(?m)^# (E\d{3})《',cand)
    if ep != [f'E{i:03}' for i in range(1,65)]:issues.append('SEQUENCE')
    edits=ledger.get('edits',[])
    if len(edits)!=ledger.get('edit_actions') or len({x['episode'] for x in edits})!=ledger.get('changed_episodes'):issues.append('LEDGER_COUNT_DISAGREES')
    for i,edit in enumerate(edits):
        if edit.get('before','') not in base:issues.append(f'BEFORE_NOT_IN_BASE:{i}')
        if edit.get('after','') not in cand:issues.append(f'AFTER_NOT_IN_CAND:{i}')
        if edit.get('before','') in cand:issues.append(f'OLD_FRAGMENT_STILL_PRESENT:{i}')
    e32=re.search(r'(?ms)^# E032《.*?(?=^# E033《)',cand)
    if not e32 or not all(z in e32.group(0) for z in ('52项','31笔','12笔','9班','120＋1288－468＝940')):issues.append('E032_FUND_FORMULA_OR_52_UNITS')
    e53=re.search(r'(?ms)^# E053《.*?(?=^# E054《)',cand)
    if not e53 or not all(z in e53.group(0) for z in ('三十文定钱','一百文尾款','两日后')):issues.append('E053_TRANSACTION_TIMELINE')
    result.update(issues=issues,valid_static=not issues,market_grade='UNVERIFIED',runtime_certified=False,release='HOLD',edits_checked=len(edits))
    return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--ledger',type=Path,required=True);p.add_argument('--out',type=Path);a=p.parse_args()
 r=assess(a.base.read_text(),a.candidate.read_text(),json.loads(a.ledger.read_text()))
 if a.out:a.out.write_text(json.dumps(r,ensure_ascii=False,indent=2))
 print(json.dumps(r,ensure_ascii=False,indent=2))
