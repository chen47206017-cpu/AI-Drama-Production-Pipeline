#!/usr/bin/env python3
"""Find screenplay-internal editorial notes. Human review required; flags never equal faults."""
import re, argparse, json
from pathlib import Path
EP=re.compile(r'^# E(\d{3})《',re.M)
TESTS={
 'NEGATED_DUPLICATE_SCREENING': r'没有重复(?:收|付|上|演|入账)|不再(?:重复|重演)',
 'UNFILMABLE_EDITORIAL_ASIDE': r'不让演员(?:口念|说)|不把\d+次交易演成|她的成长不是在|这里不必再|不需要再演',
 'FUTURE_EPISODE_LEAK': r'(?:以后|将在|要在|到)E0?\d{2,3}(?:回收|核对|兑现|验证)',
 'EXPLICIT_EDIT_NOTE': r'这一处(?:是|属于)(?:制作|拍摄|审稿)|为避免(?:穿帮|重复)|\d+秒并非(?:实际|现场)',
 'MODEL_GRADING_INSIDE_SCENE': r'(?:SSS|Production Clean|PGS\d+)[：:]?(?:已通过|放行)',
}
def scan(source):
 out=[];episode='HEADER'
 for n,line in enumerate(source.splitlines(),1):
  hit=EP.match(line)
  if hit:episode='E'+hit.group(1)
  for code,regex in TESTS.items():
   if re.search(regex,line,re.I):out.append({'episode':episode,'line':n,'code':code,'text':line[:180],'disposition':'HUMAN_REVIEW'})
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
 findings=scan(a.source.read_text(encoding='utf8'))
 data={'flags':findings,'count':len(findings),'automatic_release':False}
 if a.out:a.out.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps({'count':len(findings),'codes':sorted({x['code'] for x in findings})},ensure_ascii=False))
