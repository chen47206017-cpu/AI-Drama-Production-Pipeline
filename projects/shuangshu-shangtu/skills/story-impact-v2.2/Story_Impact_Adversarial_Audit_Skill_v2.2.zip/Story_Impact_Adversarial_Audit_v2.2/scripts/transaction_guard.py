#!/usr/bin/env python3
"""Validate structured payments and ownership. Not NLP; cannot certify unseen screenplay facts."""
import json,sys
STATES=('inquiry','deposit_received','performed','final_paid','cancelled','refunded')
def audit(transactions):
 errors=[];ids=set()
 for t in transactions:
  ident=t.get('id')
  if not ident or ident in ids:errors.append([ident,'missing_or_duplicate_id']);continue
  ids.add(ident)
  events=t.get('events',[]); cum=0; performed=False; deposit=0
  for idx,e in enumerate(events):
   state=e.get('state'); amount=e.get('amount',0)
   if state not in STATES:errors.append([ident,'bad_state',idx]);continue
   if state=='deposit_received':
    deposit+=amount
    if deposit>t.get('total_price',0):errors.append([ident,'deposit_exceeds_total'])
   if state=='performed':performed=True
   if state=='final_paid' and not performed:errors.append([ident,'final_paid_before_performed'])
   if state in ('deposit_received','final_paid'):cum+=amount
   if state=='refunded':cum-=amount
  if cum>t.get('total_price',0):errors.append([ident,'overcollected'])
  if t.get('owner') is None:errors.append([ident,'missing_owner'])
 return errors
if __name__=='__main__':
 d=json.load(open(sys.argv[1],encoding='utf-8'));print(json.dumps(audit(d['transactions']),ensure_ascii=False,indent=2))
