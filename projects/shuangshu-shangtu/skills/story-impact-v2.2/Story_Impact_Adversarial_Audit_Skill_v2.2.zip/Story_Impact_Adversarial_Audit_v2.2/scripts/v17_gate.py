#!/usr/bin/env python3
"""Cross-version screening for structural integrity and likely actor-performance compression.
Human-review heuristics are NOT release authority, not timing proof, not market scoring.
"""
from pathlib import Path
import re, hashlib, argparse,json
from v16_audit import audit, episodes

def sha(text):return hashlib.sha256(text.encode('utf-8')).hexdigest()
def analyze(text,baseline=None,project='generic'):
    a=audit(text,baseline,project);old=episodes(baseline) if baseline else {}
    new=episodes(text)
    changes=[f'E{i:03d}' for i in new if new[i]!=old.get(i)] if baseline else []
    hard=[x for x in a['flags'] if x.get('level')=='P0']
    markers=[(f'E{i:03d}',name) for i,body in new.items() for name in ('手机扫码','审计师制服','现代笔记本穿越') if name in body] if project=='双姝商途' else []
    leakage=[]
    for i,body in new.items():
        for phrase in ('不是49秒内','没有凭空出现','不算重复收','不代表当日52单','这里要强调'):
            if phrase in body: leakage.append({'episode':f'E{i:03d}','phrase':phrase,'status':'HUMAN_REVIEW'})
    result={**a,'base_sha256':sha(baseline) if baseline else None,'new_sha256':sha(text),
            'changed_episodes':changes,'changed_episode_count':len(changes),'hard_failures':hard,
            'retired_assets':markers,'editorial_leak_review':leakage,'proof_requires_actor_timing':True,
            'proof_requires_market_release':True,'release':'HOLD'}
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('script',type=Path);p.add_argument('--baseline',type=Path)
    p.add_argument('--project',default='generic');p.add_argument('--out',type=Path)
    q=p.parse_args();r=analyze(q.script.read_text(encoding='utf-8'),q.baseline.read_text(encoding='utf-8') if q.baseline else None,q.project)
    st=json.dumps(r,ensure_ascii=False,indent=2)
    if q.out:q.out.write_text(st,encoding='utf-8')
    print(st)
