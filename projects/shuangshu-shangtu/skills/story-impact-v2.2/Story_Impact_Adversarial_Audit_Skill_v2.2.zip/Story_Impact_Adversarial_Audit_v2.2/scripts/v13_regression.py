#!/usr/bin/env python3
"""Simple deterministic evidence flags; never certifies release/SSS."""
import argparse,json,re
from pathlib import Path
EP=re.compile(r'(?m)^# E(\d{3})《')
SC=re.compile(r'(?m)^### 【')

def sections(txt):
 m=list(EP.finditer(txt));return {f'E{x[1]}':txt[x.start():m[i+1].start() if i+1<len(m) else len(txt)] for i,x in enumerate(m)}

def check(a,b,frozen=tuple(f'E{i:03}' for i in range(1,6))):
 aa,bb=sections(a),sections(b)
 issues=[]
 ids=[f'E{i:03}' for i in range(1,65)]
 if list(bb)!=ids:issues.append('EPISODE_SEQUENCE_OR_COUNT')
 if len(SC.findall(b))!=268:issues.append('SCENE_COUNT_EXPECTED_268')
 if '【全剧终】' not in bb.get('E064',''):issues.append('FINALE_TAG_MISSING')
 for eid in frozen:
  if aa.get(eid)!=bb.get(eid):issues.append('FROZEN_CHANGED:'+eid)
 if not re.search(r'31\s*笔\s*[×x]\s*22',bb.get('E032','')):issues.append('E032_REVENUE_PROOF_MISSING')
 if '52笔' not in bb.get('E032',''):issues.append('E032_UNITS_NOT_EXPLICIT_52')
 if '54笔' in bb.get('E032',''):issues.append('E032_BAD_COUNT_54')
 for needle in ['120＋1288－468＝940','300文押钱','180文首月租','余460文']:
  if needle not in bb.get('E032',''):issues.append('E032_AMOUNT_NOT_FOUND:'+needle)
 if not any(x in bb.get('E053','') for x in ['【跨日卡：','【画面字幕：两日后']):issues.append('E053_TIME_PASSAGE_PROOF_REQUIRED')
 if '问得到就问' not in bb.get('E064',''):issues.append('E064_RETURN_PLAN_MISSING')
 changed=[k for k in ids if aa.get(k)!=bb.get(k)]
 return {'episodes':len(bb),'scenes':len(SC.findall(b)),'changed_count':len(changed),'changed':changed,'issues':issues,'valid_static':not issues,'runtime_certified':False,'market_grade':'UNVERIFIED','release':'HOLD'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--out',type=Path);args=p.parse_args()
 res=check(args.base.read_text(),args.candidate.read_text());raw=json.dumps(res,ensure_ascii=False,indent=2)
 if args.out:args.out.write_text(raw)
 print(raw)
