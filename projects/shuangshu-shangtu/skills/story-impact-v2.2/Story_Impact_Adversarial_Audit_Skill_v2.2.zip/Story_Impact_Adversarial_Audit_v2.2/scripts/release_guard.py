#!/usr/bin/env python3
"""Static release guard: cannot certify runtime or writing quality."""
import argparse,re,json
from pathlib import Path

def episodes(s):
    matches=list(re.finditer(r'(?m)^# (E\d{3})《[^\n]+',s))
    return {m.group(1):s[m.start():matches[i+1].start() if i+1<len(matches) else len(s)] for i,m in enumerate(matches)}
def run(text,expected_episodes=64,expected_scenes=268,freeze_ref=None,frozen=()):
    ep=episodes(text);scene_count=len(re.findall(r'(?m)^### ',text));failed=[]
    if len(ep)!=expected_episodes:failed.append('EPISODE_COUNT')
    if scene_count!=expected_scenes:failed.append('SCENE_COUNT')
    if text.count('【全剧终】')!=1:failed.append('FINALE')
    if freeze_ref:
        old=episodes(freeze_ref)
        for key in frozen:
            if ep.get(key)!=old.get(key):failed.append('FROZEN_DRIFT:'+key)
    return {'episode_count':len(ep),'scene_count':scene_count,'status':'CHECK_FAIL' if failed else 'STATIC_PASS_ONLY','failed':failed,'runtime_proved':False,'production_clean':False,'market_grade':'UNVERIFIED'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('script',type=Path);p.add_argument('--expected-episodes',type=int,default=64);p.add_argument('--expected-scenes',type=int,default=268);p.add_argument('--freeze-reference',type=Path);p.add_argument('--frozen',default='');a=p.parse_args()
    old=a.freeze_reference.read_text() if a.freeze_reference else None
    print(json.dumps(run(a.script.read_text(),a.expected_episodes,a.expected_scenes,old,[x for x in a.frozen.split(',') if x]),ensure_ascii=False,indent=2))
