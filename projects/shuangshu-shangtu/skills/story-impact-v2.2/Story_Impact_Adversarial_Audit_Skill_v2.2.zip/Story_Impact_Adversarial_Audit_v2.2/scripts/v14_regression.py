#!/usr/bin/env python3
"""Freeze, structure, cash-text, skill contamination checks. Structural signals only."""
import argparse, json, re, sys
from pathlib import Path
from editorial_leakage_gate import scan
import v13_regression as legacy

def check(base, candidate):
 res=legacy.check(base,candidate)
 issues=[x for x in res['issues'] if x!='E053_TIME_PASSAGE_PROOF_REQUIRED']
 # 时间蒙太奇可以写作52笔、52次、52项，三类别明细仍须可复核。
 epi32=legacy.sections(candidate).get('E032','')
 if re.search(r'52\s*[次项]',epi32) and '31笔' in epi32 and '12笔' in epi32 and '9班' in epi32:
  issues=[x for x in issues if x!='E032_UNITS_NOT_EXPLICIT_52']
 # v1.4 permits more natural screen-time indication.
 # re imported at module level
 ep32=re.search(r'(?ms)^# E032《.*?(?=^# E033《)',candidate)
 if not ep32 or '31笔' not in ep32.group() or '12笔' not in ep32.group() or '9班' not in ep32.group():issues.append('E032_52_BUSINESS_UNITS_NOT_SEPARATE')
 e40=re.search(r'(?ms)^# E040《.*?(?=^# E041《)',candidate)
 if not e40 or ('二十文' not in e40.group() or '十文' not in e40.group()):issues.append('E040_20_PLUS_10_MISSING')
 leaked=[x for x in scan(candidate) if x['code'] in ('FUTURE_EPISODE_LEAK','MODEL_GRADING_INSIDE_SCENE')]
 if leaked:issues.append('EDITORIAL_ANNOTATION_LEAK')
 res.update({'issues':issues,'valid_static':not issues,'editorial_flags':len(scan(candidate)),'not_quality_certification':True})
 return res
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--out',type=Path);a=p.parse_args()
 result=check(a.base.read_text(encoding='utf8'),a.candidate.read_text(encoding='utf8'))
 if a.out:a.out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
 print(json.dumps(result,ensure_ascii=False,indent=2))
