#!/usr/bin/env python3
"""Narrative case contract checks for public-office impartiality and real service fulfillment.
Structured story assertions, not determination of actual legality, filming duration, or market outcomes.
"""
import json,argparse
from pathlib import Path

def case_check(c):
    failures=[]; warnings=[]
    def p0(code): failures.append(code)
    def warn(code): warnings.append(code)
    kind=c.get('kind','')
    if kind=='official':
        if c.get('special_access_for_romance') or c.get('official_awards_private_contract'):
            p0('OFFICE_PRIVATE_FAVOR')
        if c.get('public_blockade') and not c.get('observable_public_hazard'):
            p0('SAFETY_WITHOUT_INDEPENDENT_BASIS')
        if c.get('comparable_rival') and c.get('different_treatment_without_public_reason'):
            p0('UNEQUAL_COMPETITOR_RULE')
        if c.get('merchant_holds_public_guard_line'):
            p0('MERCHANT_AS_PUBLIC_GUARD')
        if c.get('official_leaves_guard') and not all([c.get('guard_receiver'),c.get('route_repeated'),c.get('seal_still_active')]):
            p0('SHIFT_WITHOUT_PROVEN_HANDOFF')
        if c.get('reopen_route') and not (c.get('guard_arrived') and c.get('on_site_route_approved')):
            p0('NO_REOPEN_BEFORE_SITE_CHECK')
        if c.get('official_romantic_interaction') and not c.get('public_private_separation'):
            warn('OFFICE_ROMANCE_SEPARATION_REVIEW')
    if kind=='commercial':
        if c.get('completed_service_in_pricing_scene') and c.get('same_service_fulfilled_later'):
            p0('DOUBLE_SERVICE_OR_UNPAID_SAMPLE')
        if c.get('cash_as_revenue_before_delivery'):
            p0('ADVANCE_AS_EARNED_REVENUE')
        if c.get('rival_staff_demonstrates_at_hero_shop') and not c.get('independent_rival_motive'):
            p0('RIVAL_SERVES_HERO_NO_MOTIVE')
        if c.get('sale_claimed') and not all([c.get('customer_chose'),c.get('owner_delivered'),c.get('money_state_known')]):
            p0('UNPROVEN_VICTORY')
        if c.get('public_office_subsidizes_private_deal_without_basis'):
            p0('OFFICE_SUBSIDIZES_PRIVATE_DEAL')
    if kind=='event_id':
        if c.get('two_separate_incidents') and not c.get('separate_injured_person_ids'):
            warn('INJURED_PARTY_ID_COLLISION')
    return {'id':c.get('id'),'kind':kind,'hard_failures':failures,'human_review':warnings,
            'status':'STRUCTURED_PASS' if not failures else 'FLAGGED',
            'disclaimer':'Asserted scene facts only; requires human comparison with complete script.'}

def run(cases): return [case_check(c) for c in cases]
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cases',required=True,type=Path);p.add_argument('--out',type=Path)
    args=p.parse_args();res=run(json.loads(args.cases.read_text(encoding='utf-8')))
    txt=json.dumps(res,ensure_ascii=False,indent=2)
    if args.out:args.out.write_text(txt,encoding='utf-8')
    print(txt)
