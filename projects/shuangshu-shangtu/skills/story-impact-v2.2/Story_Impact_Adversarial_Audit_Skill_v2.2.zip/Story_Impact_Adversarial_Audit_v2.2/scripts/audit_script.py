#!/usr/bin/env python3
"""Static screenplay extractor. Emits FLAGS only; never certifies drama/runtime/release quality."""
from __future__ import annotations
import argparse, csv, json, re
from collections import Counter
from pathlib import Path
from statistics import median

EP_RE = re.compile(r'(?m)^#\s+E(\d{3})《([^》]+)》\s*$')
SC_RE = re.compile(r'(?m)^###\s*【([^】]+)】\s*$')
TIME_RE = re.compile(r'(\d{2}):(\d{2})\s*[–—−-]\s*(\d{2}):(\d{2})')
HANZI_RE = re.compile(r'[\u4e00-\u9fff]')
# Speech with double Chinese quotes following a colon; alternative short labels are not treated as quotes.
SPEECH_RE = re.compile(r'[：:]\s*[“\"]([^”\"]{1,500})[”\"]')


def seconds(m: re.Match) -> tuple[int,int]:
    return int(m[1])*60+int(m[2]),int(m[3])*60+int(m[4])


def parse(source: str):
    matches=list(EP_RE.finditer(source))
    rows=[]; issues=[]
    for i,m in enumerate(matches):
        eid=f'E{m[1]}'; block=source[m.end():matches[i+1].start() if i+1<len(matches) else len(source)]
        scenes=list(SC_RE.finditer(block))
        spoken=''.join(SPEECH_RE.findall(block))
        spoken_char=len(HANZI_RE.findall(spoken))
        total_hanzi=len(HANZI_RE.findall(block))
        spans=[]
        for j,scene in enumerate(scenes):
            mark=TIME_RE.search(scene[1])
            if mark:
                start,end=seconds(mark)
                spans.append((start,end))
            else:
                issues.append(dict(episode=eid,code='SCENE_UNTIMED',severity='FLAG',detail=scene[1][:70]))
        spans_sorted=sorted(spans)
        if spans_sorted and spans_sorted[0][0]!=0:
            issues.append(dict(episode=eid,code='START_NOT_ZERO',severity='FLAG',detail=f'first scene begins {spans_sorted[0][0]}s'))
        for a,b in zip(spans_sorted,spans_sorted[1:]):
            if b[0]!=a[1]:
                issues.append(dict(episode=eid,code='TIME_GAP_OR_OVERLAP',severity='FLAG',detail=f'{a} -> {b}'))
        for start,end in spans_sorted:
            if end<=start:
                issues.append(dict(episode=eid,code='NON_POSITIVE_SCENE_DURATION',severity='FLAG',detail=f'{start}..{end}'))
        end=max((x[1] for x in spans_sorted),default=0)
        if total_hanzi <= 700:
            issues.append(dict(episode=eid,code='LOW_TEXT_FOR_LONG_TIMECODE',severity='REVIEW',detail=f'{total_hanzi} Hanzi across {end}s; physical performance may fill time'))
        if spoken_char <= 100:
            issues.append(dict(episode=eid,code='SPARSE_DIALOGUE_REQUIRES_BLOCKING_PROOF',severity='REVIEW',detail=f'{spoken_char} spoken Hanzi; not automatically a fault'))
        if not (re.search(fr'【{eid}完】',block) or (eid == 'E064' and '【全剧终】' in block)):
            issues.append(dict(episode=eid,code='MISSING_EPISODE_END',severity='CHECK',detail='no tagged end marker'))
        rows.append(dict(episode=eid,title=m[2],scene_count=len(scenes),chinese_characters=total_hanzi,dialogue_hanzi=spoken_char,last_timed_second=end,unverified_runtime=True))
    ids=[x['episode'] for x in rows]
    missing=[f'E{i:03d}' for i in range(1,65) if f'E{i:03d}' not in ids]
    duplicated=[x for x,n in Counter(ids).items() if n>1]
    stats=dict(episode_count=len(rows),missing_episode_ids=missing,duplicate_episode_ids=duplicated,
               total_scenes=sum(x['scene_count'] for x in rows),episodes_timed_to_150s=sum(x['last_timed_second']==150 for x in rows),
               low_text_episode_count=sum(x['chinese_characters']<=700 for x in rows),
               median_dialogue_hanzi=median((x['dialogue_hanzi'] for x in rows)) if rows else None,
               static_flags=len(issues),can_certify_actual_runtime=False,can_certify_script_quality=False,release_status='HOLD')
    return rows,issues,stats


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path)
    p.add_argument('--output-dir',type=Path,default=Path('audit_out'))
    args=p.parse_args(); data=args.input.read_text(encoding='utf-8')
    rows,issues,summary=parse(data)
    args.output_dir.mkdir(parents=True,exist_ok=True)
    with (args.output_dir/'episodes.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['episode'])
        w.writeheader();w.writerows(rows)
    with (args.output_dir/'flags.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['episode','code','severity','detail']);w.writeheader();w.writerows(issues)
    (args.output_dir/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
