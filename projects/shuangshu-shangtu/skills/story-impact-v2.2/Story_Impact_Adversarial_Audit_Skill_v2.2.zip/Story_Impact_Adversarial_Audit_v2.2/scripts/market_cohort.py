#!/usr/bin/env python3
"""对已上映同质内容的结构化增量数据作经验分位数内部评级；不对剧本打SSS。"""
import json,sys,statistics
REQUIRED=('platform','format','metric','period_start','period_end','aggregation','source_date','views')
def classify(records, target, min_n=30):
 if not target.get('released',False):return {'grade':'UNVERIFIED','reason':'unreleased'}
 if len(records)<min_n:return {'grade':'INSUFFICIENT_SAMPLE','count':len(records)}
 if any(any(k not in r for k in REQUIRED) for r in records):return {'grade':'INVALID_DATA','reason':'missing_metadata'}
 keys=('platform','format','metric','period_start','period_end','aggregation')
 for k in keys:
  if len({r[k] for r in records})!=1:return {'grade':'MIXED_COHORT','reason':k}
  if target.get(k)!=records[0][k]:return {'grade':'NONCOMPARABLE_TARGET','reason':k}
 a=sorted(float(r['views']) for r in records)
 v=target.get('views')
 if v is None:return {'grade':'UNVERIFIED','reason':'no_observed_views'}
 rank=sum(x<=float(v) for x in a)/len(a)
 return {'grade':'SSS' if rank>=.99 else 'SS' if rank>=.97 else 'S' if rank>=.90 else 'BELOW_S','percentile':round(rank,4),'count':len(records),'status':'INTERNAL_COHORT_ONLY'}
if __name__=='__main__':
 d=json.load(open(sys.argv[1],encoding='utf-8'));print(json.dumps(classify(d['records'],d['target']),ensure_ascii=False,indent=2))
