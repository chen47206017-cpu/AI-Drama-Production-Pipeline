#!/usr/bin/env python3
"""Structured narrative-logic checks only. Never determines legality, filmability, or market quality."""
import json, argparse, re
from pathlib import Path

def audit_case(c):
    findings=[]
    def bad(code,message):findings.append({'code':code,'severity':'P0','message':message})
    if c.get('official_decides_private_contract'):
        bad('PUBLIC_POWER_CONTRACT','公职人员替私人商户裁决商约／赔偿。')
    if c.get('selective_exemption_for_love'):
        bad('ROMANTIC_FAVOR','公职权力因私人情感给予某商户例外。')
    if c.get('safety_stop') and not c.get('independent_hazard'):
        bad('UNFOUNDED_PUBLIC_STOP','公职封控没有独立可观测的公共危险／规则依据。')
    if c.get('guard_line_held_by_merchant'):
        bad('DELEGATED_PUBLIC_SEAL','正式封控绳／巡岗更牌由商业当事人替代持守。')
    if c.get('goods_moved_by_official') and not (c.get('owner_agreed') or c.get('emergency_necessity_documented')):
        bad('PROPERTY_WITHOUT_BASIS','公务搬货未显示货主认可或可说明的紧急必要性。')
    if c.get('official_leaves_live_blockade') and not (c.get('handoff_staff') and c.get('handoff_route') and c.get('handoff_confirmed')):
        bad('UNSTAFFED_BLOCKADE','封控尚有效，公务人员离岗前没有可查证的接班交接。')
    if c.get('route_reopened') and not (c.get('guard_present') and c.get('physical_route_verified')):
        bad('UNVERIFIED_REOPEN','人员／道路没有实际验收便放行。')
    if c.get('staff_confirmed_on_paper') and c.get('route_reopened') and not c.get('staff_arrived'):
        bad('PAPER_STAFF_IS_NOT_ARRIVAL','约好雇人不能等同到岗。')
    return {'id':c.get('id'),'hard_failures':findings,'status':'FLAGGED' if findings else 'STRUCTURED_GATE_PASS','warning':'This tool reviews structured story assertions, not scene truth or fictional law.'}

WATCH=[('手持封控','接过另一端'),('暗中通融','替她通融'),('身份快捷办理','官员开绿灯'),('巡守预签','提前画了押'),('未到岗开街','尚未到岗却开街')]
def scan_script(text):
    return [{'marker':x,'code':k,'status':'HUMAN_REVIEW','offset':m.start()} for k,x in WATCH for m in re.finditer(re.escape(x),text)]

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--cases',type=Path);p.add_argument('--script',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args();res={}
    if a.cases:res['cases']=[audit_case(c) for c in json.loads(a.cases.read_text(encoding='utf8'))]
    if a.script:res['text_only_watchlist']=scan_script(a.script.read_text(encoding='utf8'))
    st=json.dumps(res,ensure_ascii=False,indent=2)
    if a.out:a.out.write_text(st,encoding='utf8')
    print(st)
