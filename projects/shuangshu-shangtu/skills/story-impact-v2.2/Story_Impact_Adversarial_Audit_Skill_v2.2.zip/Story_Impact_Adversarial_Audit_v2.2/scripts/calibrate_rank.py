#!/usr/bin/env python3
"""Strictly segregated market-metric grade. UNVERIFIED for unsupported scopes."""
import argparse,json

def classify(platform,format,metric,period,value,published=True):
    result=dict(platform=platform,format=format,metric=metric,period=period,value=value,grade=None,scope='internal_market_only')
    if not published:
        result.update(grade='UNVERIFIED',reason='Unreleased scripts have no observed market views')
    elif (platform,format,metric,period)!=('douyin','ai_drama','monthly_increment_views','2026-09'):
        result.update(grade='UNVERIFIED',reason='Requires separate matched platform/format/window calibration; heat cannot become views')
    else:
        result.update(grade=('SSS' if value>=2_000_000_000 else 'SS' if value>=1_000_000_000 else 'S' if value>=500_000_000 else 'A' if value>=100_000_000 else 'B'),reason='Provisional internal thresholds; not platform official')
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--metric',required=True);p.add_argument('--platform',required=True);p.add_argument('--format',required=True);p.add_argument('--period',required=True);p.add_argument('--value',required=True,type=int);p.add_argument('--unreleased',action='store_true');a=p.parse_args()
    print(json.dumps(classify(a.platform,a.format,a.metric,a.period,a.value,not a.unreleased),ensure_ascii=False,indent=2))
