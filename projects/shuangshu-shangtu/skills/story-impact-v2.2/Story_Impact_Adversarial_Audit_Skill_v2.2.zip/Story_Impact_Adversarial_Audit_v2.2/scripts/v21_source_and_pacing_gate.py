#!/usr/bin/env python3
"""Evidence-driven guards; advisory only. No automated story-quality or release authority."""
import re

def clean(s):
    return re.sub(r"[\s`*\u200b]", "", s)

def quote_anchor_check(script, claims):
    """All claimed verbatim script quotes must exist in that episode.
    claims: [{episode: integer, quote: str, claimed_exact: bool}].
    Paraphrases do not pass verbatim proof; they are unverified, not necessarily false.
    """
    eptexts={int(n):b for n,b in re.findall(r"(?m)^# E(\d{3})《[^\n]+》\n(.*?)(?=^# E\d{3}《|\Z)",script,re.S|re.M)}
    out=[]
    for c in claims:
        n=int(c['episode']); q=clean(c['quote']); source=clean(eptexts.get(n,''))
        if n not in eptexts: state='UNKNOWN_EPISODE'
        elif not q: state='BAD_CLAIM'
        elif q in source: state='EXACT_ANCHOR_FOUND'
        elif c.get('claimed_exact',False): state='UNSUPPORTED_QUOTE'
        else: state='PARAPHRASE_NEEDS_HUMAN_READ'
        out.append({'episode':n,'quote':c['quote'],'evidence_status':state})
    return out

def platform_metric_cohort(a,b):
    """Only compare same content form, platform, unit, metric definition, window."""
    fields=('platform','format','metric','unit','window_days')
    return all(a.get(k) is not None and a.get(k)==b.get(k) for k in fields)

def prohibit_prelaunch_market_tier(released, verified_play_data):
    return bool(released and verified_play_data)

def episode_pacing_flags(script):
    """Scene clock structure and simple compression heuristics; not actual performance seconds."""
    eps=re.findall(r"(?m)^# E(\d{3})《[^\n]+》\n(.*?)(?=^# E\d{3}《|\Z)",script,re.S|re.M)
    res=[]
    for n,b in eps:
        times=[]
        for label in re.findall(r"(?m)^### 【([^\n]+)】",b):
            m=re.search(r'(\d{2}:\d{2})[–-](\d{2}:\d{2})',label)
            if m:times.append(tuple(int(x[:2])*60+int(x[3:]) for x in m.groups()))
        if times and (times[0][0]!=0 or times[-1][1]!=150):res.append(f'E{n}:clock_bounds')
        for i,p in enumerate(times):
            if p[0]>=p[1]:res.append(f'E{n}:nonpositive_scene_{i}')
            if i and p[0]!=times[i-1][1]:res.append(f'E{n}:scene_gap_or_overlap_{i}')
        if not times:res.append(f'E{n}:no_clocks')
    return {'episodes':len(eps),'warnings':res,'certifies_performance':False}

def project_exclusions(script, forbidden):
    return {term:script.count(term) for term in forbidden if term in script}
