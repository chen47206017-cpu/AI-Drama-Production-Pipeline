# 2026年10月15日样本与可迁移机制

- DataEye 2026年9月真人短剧百强榜（10月12日），https://www.thepaper.cn/newsDetail_forward_34234356 ，披露“热力值”及不同榜单，不能把热度变成播放量。
- DataEye 2026上半年真人微短剧数据报告，https://www.dataeye.com/report.html?key=DataEye2026%E4%B8%8A%E5%8D%8A%E5%B9%B4%E7%9C%9F%E4%BA%BA%E5%BE%AE%E7%9F%AD%E5%89%A7%E6%95%B0%E6%8D%AE%E6%8A%A5%E5%91%8A ，真人原生抖音上半年16部超10亿增量（半年度，不是月度）。
- DataEye 2026年9月AI剧漫剧榜（10月10日），https://m.thepaper.cn/newsDetail_forward_34223675 ，百强累计764.6亿增量；AI仿真人剧榜首单月增量23.7亿。不得迁移为真人剧阈值。
- 广电总局《微短剧发展管理办法》（2026年9月1日起施行），https://www.nrta.gov.cn/art/2026/7/31/art_113_73785.html ，不含“90分为SSS”的剧本等级。
- 《梦华录》定位与场所错配：CBNData https://www.cbndata.com/information/247419 ，技术不是“会算”，而是失误、客户任务、商业选择与后续结果。
- 故事层面迁移：真正卖出、做完、收尾款、失去复购机会；对手也实际支付工钱与承担退钱后果。禁止搬运原剧情和台词。
